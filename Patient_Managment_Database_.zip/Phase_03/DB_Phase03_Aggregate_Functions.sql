/*-----------------------------------------------------3rd Phase-----------------------------------------------------------------------*/
/*-------------------------------------------------AGGREGATE FUNCTIONS-----------------------------------------------------------------*/
use Hospital;

/*--------------------( 1 )--------------*/


--Display the distinct blood groups of all patients.
select distinct Blood_group from Patient;


/*--------------------( 2 )--------------*/


--Display the count of patients for each blood group.
select Blood_group, count(*) as Total_Patients from Patient
group by Blood_group;


/*--------------------( 3 )--------------*/


--Display the average salary of doctors who have a salary greater than $5000.
select avg(Salary) as Average_Salary from Doctor
where Salary > 5000;


/*--------------------( 4 )--------------*/


--Retrieve the top 5 highest-paid doctors.
/* MySQL syntax --->     SELECT * FROM Doctor ORDER BY Salary DESC LIMIT 5;*/
select top 5 * from Doctor order by Salary desc;


/*--------------------( 5 )--------------*/


--Retrieve the total amount of bills for each patient, and display only those patients whose total bill amount is greater than $1000.
select Patient_ID, sum(Amount) as Total_Bill_Amount from Bill
group by Patient_ID, Amount
having Amount > 1000;


/*--------------------( 6 )--------------*/


--Select the average, maximum, and minimum values of the "Salary" from Doctors.
select AVG(Salary) as AverageSalary, max(Salary) as MaxSalary, min(Salary) as MinSalary
from Doctor;


/*--------------------( 7 )--------------*/


--Retrieve the patients along with their average age, grouped by their blood group, and sorted by the average age in ascending order.
select Blood_group, avg(Age) as Average_Age from Patient
group by Blood_group order by Average_Age asc;


/*----------------------------------------------------------------------------------------------------------------------------------------------*/

