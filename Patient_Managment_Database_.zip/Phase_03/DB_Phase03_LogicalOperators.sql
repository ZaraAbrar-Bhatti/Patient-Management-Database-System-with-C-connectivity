/*-----------------------------------------------------3rd Phase-----------------------------------------------------------------------*/
/*------------------------------------------------LOGICAL OPERATORS--------------------------------------------------------------------------*/
use Hospital;

/*--------------------( 1 )--------------*/


--Display all doctors whose salary is between 5000 and 7000
select * from Doctor where Salary between 5000 and 8000;


/*--------------------( 2 )--------------*/


--Display all patients who have blood group 'AB+' or 'O-'
select * from Patient where Blood_group in ('AB+', 'O-');


/*--------------------( 3 )--------------*/


--Display all doctors who are not male.
select * from Doctor where Sex = 'Male' and Cabin_no > 5;


/*--------------------( 4 )--------------*/


--Display the address of Patient where condition is not critical
select * from Patient where Patient_type <> 'Emergency';



/*--------------------( 5 )--------------*/


--Display all doctors whose First name starts with 'J' or 'R'.
select * from Doctor where First_name like 'Dr.J%' OR First_name LIKE 'Dr.R%';



/*--------------------( 6 )--------------*/


--Display all patients whose address does not contains the word 'Street'.
select * from Patient where Adress not like '%Street%';


/*--------------------( 7 )--------------*/


--Display all doctors whose email addresses end with '@gmail.com'.
select * from Doctor where Email_ID like '%@gmail.com';




/*--------------------------------------------------------------------------------------------------------------------------------------------------*/