/*-----------------------------------------------------3rd Phase-----------------------------------------------------------------------*/
/*------------------------------------------------------JOINS--------------------------------------------------------------------------*/
use Hospital;

/*--------------------( 1 )--------------*/


--Display the details of patients along with their assigned doctors.
select Patient.Patient_ID, Patient.Patient_name_, Doctor.First_name as Doctor_Assigned
from Patient
join Diagnosis on Patient.Patient_ID = Diagnosis.Patient_ID
join Doctor on Doctor.Doc_ID = Diagnosis.Patient_ID;


/*--------------------( 2 )--------------*/


--Display the bill details along with the corresponding patient's name.
select Bill.Bill_no, Bill.Amount, Patient.Patient_name_
from Bill
inner join Patient on Bill.Patient_ID = Patient.Patient_ID;


/*--------------------( 3 )--------------*/


--Display the prescription details along with the corresponding patient's name and doctor's name.
select Prescription.Presc_ID, Prescription.Date_, 
Patient.Patient_name_, Doctor.First_name as Doctor_Assigned
from Prescription
inner join Patient on Prescription.Patient_ID = Patient.Patient_ID
inner join Doctor on Prescription.Doc_ID = Doctor.Doc_ID;


/*--------------------( 4 )--------------*/


--Display the patients along with their assigned rooms and their location.
select Patient.Patient_ID, Patient.Patient_name_, Room.Room_no, Room.Locat
from Patient
inner join Room on Patient.Patient_ID = Room.Room_no;


/*--------------------( 5 )--------------*/


--Display the details of patients along with their bill details, the corresponding doctor's name.
select Patient.Patient_ID, Patient.Patient_name_, Bill.Bill_no, Bill.Amount,
Doctor.First_name as Doctor_Assigned
from Patient
left join Bill on Patient.Patient_ID = Bill.Patient_ID
left join Diagnosis on Patient.Patient_ID = Diagnosis.Patient_ID
left join Doctor on Doctor.Doc_ID = Diagnosis.Doc_ID
left join Medical_Shop on Patient.Patient_ID = Medical_Shop.Patient_ID
left join Pharmacy on Pharmacy.Med_Bill_no = Medical_Shop.Med_Bill_no


/*--------------------( 6 )--------------*/


--Display the details of patients along with their assigned rooms and the receptionist details who admitted them.
select Patient.Patient_ID, Patient.Patient_name_, 
Room.Room_no, Room.Locat, Receptionist.R_Name
from Patient
inner join Room on Patient.Patient_ID = Room.Room_no
left join Receptionist on Patient.Patient_ID = Receptionist.Patient_ID;


/*--------------------( 7 )--------------*/


--Retrieve the patients along with the corresponding nurse details who is taking care of them.
select Patient.Patient_ID, Patient.Patient_name_, Nurse.N_Name
from Patient
left join Patient_Cheakup on Patient.Patient_ID = Patient_Cheakup.Patient_ID
left join Nurse on Nurse.N_Name = Patient_Cheakup.N_Name;


/*---------------------------------------------------------------------------------------------------------------------------------------------*/








