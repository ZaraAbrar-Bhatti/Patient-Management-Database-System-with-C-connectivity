/*-----------------------------------------------------3rd Phase-----------------------------------------------------------------------*/
/*---------------------------------------------------NESTED QURIES------------------------------------------------------------------*/
use Hospital;

/*--------------------( 1 )--------------*/


--Select the patients who have a bill amount greater than the average bill amount of all patients.
select Patient_ID, Patient_name_ from Patient where Patient_ID in
    (select Patient_ID from Bill where Amount > 
       (select avg(Amount) from Bill));


/*--------------------( 2 )--------------*/


--Select the doctors who have treated patients with a blood group that is present in the Patient table.
select First_name as Doctor_First_Name, Last_Name as Doctor_Last_Name from Doctor where Doc_ID IN 
    (select Patient_ID from Patient where Blood_group in 
        (select distinct Blood_group from Patient));


/*--------------------( 3 )--------------*/


--Select the patients who have been admitted before any doctor with the last name "Rizwan."
select Patient_ID, Patient_name_ from Patient where Admit_date < 
    (select min(Admit_date) from Patient where Patient_ID in 
        (select Doc_ID from Doctor where Last_name = 'Rizwan'));


/*--------------------( 4 )--------------*/


/*Select the patients who have a bill amount greater than the average bill amount of patients
treated by doctors with a salary greater than the average salary of all doctors.*/
select Patient_ID, Patient_name_ from Patient where Patient_ID in 
    (select Patient_ID from Bill where Amount > 
        (select avg(Amount) from Bill where Patient_ID in 
            (select Doc_ID from Doctor where Salary > 
                (select avg(Salary) from Doctor))));


/*-----------------------------------------------------------------------------------------------------------------------------------------------*/