/*-----------------------------------------------------3rd Phase-----------------------------------------------------------------------*/
/*--------------------------------------------PROCEDURES + TRIGGERS + Views----------------------------------------------------------*/
use Hospital;

/*--------------------( 1 )--------------*/


--Create a view that displays the details of doctors who have a salary greater than 130,0000.
create view High_Salary_Doctors 
as
select * from Doctor where Salary > 1300000;

select * from High_Salary_Doctors;


/*--------------------( 2 )--------------*/


--Create a stored procedure that displays the details of patients based on the given blood group.
create procedure Get_Patient
@Blood_group varchar(8)
as
begin
    select * from Patient where Blood_group = @Blood_group;
end;

execute Get_Patient 'AB+'


/*--------------------( 3 )--------------*/


--Create a view that displays the details of female doctors from the "Doctor" table.
create view Female_Doctors 
as
select * from Doctor where Sex = 'Female';

select * from Female_Doctors 


/*--------------------( 4 )--------------*/


--Create a stored procedure that displays the details of patients based on their type.
create procedure Patient_Details
@Patient_type varchar(20)
as
begin
    select * from Patient where Patient_type = @Patient_type;
end;
select * from Patient;
exec Patient_Details 'Psychological'


/*--------------------( 5 )--------------*/


--Create trigger that display the table whenever any change occurs to it.
create trigger Display_Parm on Pharmacy
after insert,update,delete
as begin 
select * from Pharmacy
end

/*--------------------------------------------------------------------------------------------------------------------------------------------*/





/*----------------------------------------Search Procedures in each Table---------------------------------------------*/
/*Doctor*/
create procedure Search_Doctor
@Doc_ID int
as
begin
select * from Doctor
where Doc_ID = @Doc_ID;
end

create procedure Search_No
@Doc_ID int
as
begin
select * from Phone_No
where Doc_ID = @Doc_ID;
end

create procedure Search_Skill
@Doc_ID int
as
begin
select * from Skill
where Doc_ID = @Doc_ID;
end
/*Patient*/
create procedure Search_Patient
@Patient_ID int
as
begin
select * from Patient
where Patient_ID = @Patient_ID;
end

create procedure Search_Num
@Patient_ID int
as
begin
select * from Phone_Num
where Patient_ID = @Patient_ID;
end
/*Bill*/
create procedure Search_Bill
@Patient_name varchar(20)
as
begin
select * from Bill
where Patient_name = @Patient_name;
end
/*Prescription*/
create procedure Search_Presc
@Presc_ID int
as
begin
select * from Prescription
where Presc_ID = @Presc_ID;
end
/*Pharmacy*/
create procedure Search_Pharm
@Patient_name_ varchar(20)
as
begin
select * from Pharmacy
where Patient_name_ = @Patient_name_;
end
/*Room*/
create procedure Search_Room
@Room_no int
as
begin
select * from Room
where Room_no = @Room_no;
end
/*Receptionist*/
create procedure Search_Receptionist
@R_Name varchar(20)
as
begin
select * from Receptionist
where R_Name = @R_Name;
end

create procedure Search_Contact
@R_Name varchar(20)
as
begin
select * from Contact
where R_Name = @R_Name;
end
/*Laboratory*/
create procedure Search_Lab
@T_name varchar(20)
as
begin
select * from Laboratory
where T_name = @T_name;
end

create procedure Search_Number
@T_name varchar(20)
as
begin
select * from Number
where T_name = @T_name;
end
/*Nurse*/
create procedure Search_Nurse
@N_Name varchar(20)
as
begin
select * from Nurse
where N_Name = @N_Name;
end

create procedure Search_Mobile
@N_Name varchar(20)
as
begin
select * from Mobile
where N_Name = @N_Name;
end
/*Aedmin*/
create procedure Search_Admin
@Admin_Name varchar(20)
as
begin
select * from Aedmin
where Admin_Name = @Admin_Name;
end

create procedure Search_Phone
@Admin_Name varchar(20)
as
begin
select * from Phone
where Admin_Name = @Admin_Name;
end

/*Execution*/

exec Search_Doctor 02;
exec Search_No 02;
exec Search_Skill 02;
exec Search_Patient 02;
exec Search_Num 02;
exec Search_Bill 'Shahan Butt';
exec Search_Presc 02;
exec Search_Pharm 'Asma Amir';
exec Search_Room 05;
exec Search_Receptionist 'Zuriat Naeem';
exec Search_Contact 'Rubab Khuram';
exec Search_Lab 'Abu-Bakar';
exec Search_Number 'Naeem Ahmad';
exec Search_Nurse 'Anoushe Bajwa';
exec Search_Mobile 'Abdul Jabbar' ;
exec Search_Admin 'Nabeel Bukhari';
exec Search_Phone 'Asmat Kazmi';

/*-----------------------------------------------------------------------------------------------------------------------------------*/