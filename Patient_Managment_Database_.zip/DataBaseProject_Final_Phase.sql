/*--------------------------------------------------PROJECT 1st + 2nd PHASE---------------------------------------------------------------------------*/ 
create  database Hospital;
use Hospital;

/*----------------------------Creating Tables of entities-------------------------*/
create table Doctor(
Doc_ID int identity(1,1) primary key,
First_name varchar(20),
Last_name varchar(20),
Paswrd varchar(10),
Sex varchar(8),
Salary float,
Email_ID varchar(50),
Cabin_no int
)
create table Phone_No(                                        /*Multivalued attribute*/
Doc_ID int foreign key references Doctor(Doc_ID),
Phone_no int,
)
create table Skill(                                          /*Multivalued attribute*/
Doc_ID int foreign key references Doctor(Doc_ID),
Specialization varchar(20),
)

create table Patient(
Patient_ID int identity(1,1) primary key,
Patient_name_ varchar(20),
Patient_type varchar(20),
Sex varchar(8),
Blood_group varchar(8),
DOB date,
Age int,
Admit_date date,
Adress varchar(30),
)
create table Phone_Num(                                     /*Multivalued attribute*/
Patient_ID int foreign key references Patient(Patient_ID),
Phone_no int,
)

create table Bill(                                         /*Weak Entity*/
Bill_no int identity(1,1),
Patient_ID int,
Patient_name varchar(20),
Amount int,
primary key(Bill_no,Patient_ID),
foreign key(Patient_Id) references Patient(Patient_ID)     /*Weak Relation b/w Patient-Bill*/
)

create table Prescription(
Presc_ID int identity(1,1) primary key,                                              /*Weak Entity*/
Patient_ID int,
Doc_ID int,
Date_ date,
foreign key (Doc_ID) references Doctor(Doc_ID),
foreign key (Patient_ID) references Patient(Patient_ID),               /*Weak Relation b/w Patient-Prescription*/
Presc_hierarchy int foreign key references Prescription(Presc_ID),     /*Recurssive Relation*/
)

create table Pharmacy(
Med_Bill_no int identity(1,1) primary key,
Patient_name_ varchar(20),
Amount float
)

create table Room(                                               /*Relation b/w Patient-Room*/
Room_no int primary key,
Locat varchar(40),
foreign key (Room_no) references Patient(Patient_ID)
)

create table Laboratory(
T_name varchar(15) primary key,
User_nam varchar(15),
Paswrd int,
Gender varchar(8),
Email_ID varchar(50),
Adress varchar(30),
Salary int,
Patient_ID int foreign key references Patient(Patient_ID),            /*Relation b/w Patient-Lab*/
)
create table Number(                                                  /*Multivalued attribute*/
T_Name varchar(15) foreign key references Laboratory(T_Name),
Phone_no int,
)

create table Receptionist(
R_Name varchar(15) primary key,
User_Nam varchar(15),
Paswrd int,
Gender varchar(8),
Email_ID varchar(50),
Salary int,
Patient_ID int foreign key references Patient(Patient_ID)                         /*Relation b/w Patient-Receptionist*/
)
create table Contact(                                                            /*Multivalued attribute*/
R_Name varchar(15) foreign key references Receptionist(R_Name),
Phone_no int,
)

create table Nurse(
N_Name varchar(15) primary key,
User_Nam varchar(15),
Paswrd int,
Salary int,
Gender varchar(8),
Adress varchar(30),         
)
create table Mobile(                                      /*Multivalued attribute*/
N_Name varchar(15) foreign key references Nurse(N_Name),
Phone_no int,
)

create table Aedmin(
Admin_Name varchar(15) primary key,
User_Nam varchar(15),
Paswrd int,
Gender varchar(8),
Email_ID varchar(50),
Salary int,
T_Name varchar(15) foreign key references Laboratory(T_Name),           /*Relation b/w Lab-Aedmin*/
Room_cheaking int foreign key references Room(Room_no),                  /*Relation b/w Room-Aedmin*/
Worker_Name varchar(15) foreign key references Nurse(N_Name),              /*Relation b/w Nurse-Aedmin*/
Bill int foreign key references Pharmacy(Med_Bill_no),                     /*Relation b/w Pharmacy-Aedmin*/
)
create table Phone(                                                     /*Multivalued attribute*/
Admin_Name varchar(15) foreign key references Aedmin(Admin_Name),
Phone_no int,
)

/*-------------------------Creating Tables for relations----------------------*/
create table Diagnosis(                                 /*Relation b/w Patient-Doctor*/
Doc_ID int foreign key references Doctor(Doc_ID),
Patient_ID int foreign key references Patient(Patient_ID)
)

create table Medical_Shop(                              /*Relation b/w Patient-Pharmacy*/
Shop_No int,
Locat varchar(30),
Patient_ID int foreign key references Patient(Patient_ID),
Med_Bill_no int foreign key references Pharmacy(Med_Bill_no),
)

create table Patient_Cheakup(                          /*Relation b/w Patient-Nurse*/     
N_Name varchar(15) foreign key references Nurse(N_Name),
Patient_ID int foreign key references Patient(Patient_ID)
)


/*----------------------------------------Insertion into the tables-----------------------------*/

/* Doctor */
insert into Doctor values('Dr.Jaweria','Rizwan','@3974','Female',1500000,'javeria@gmail.com',01);
insert into Doctor values('Dr.Zara','Abrar','@5544','Female',14000000,'zzaranoor8@gmail.com',02);
insert into Doctor values('Dr.Reshmail','Fatima','@5804','Female',1300000,'resh04@gmail.com',05);
insert into Doctor values('Dr.Alizey','Nadeem','@8624','Female',1200000,'alizeygull@gmail.com',15);
insert into Doctor values('Dr.Haroon','Javaid','@6700','Male',1700000,'haroon.458@gmail.com',13);
insert into Doctor values('Dr.Asad','Jaffar','@0004','Male',1500000,'jaffar@gmail.com',07);
insert into Doctor values('Dr.Nadeem','Baig','@2948','Male',13000000,'nadeembaig@gmail.com',09);
insert into Doctor values('Dr.Mahnoor','Alam','@3344','Female',1200000,'alam67@gmail.com',12);
insert into Phone_No values(01,929999);
insert into Phone_No values(02,929429);
insert into Phone_No values(03,927523);
insert into Phone_No values(04,920000);
insert into Phone_No values(05,924360);
insert into Phone_No values(06,927841);
insert into Phone_No values(07,928475);
insert into Phone_No values(08,927625);
insert into Skill values(02,'Cardiology');
insert into Skill values(02,'Psychology');
insert into Skill values(01,'Psychiatry');
insert into Skill values(03,'Gynecology');
insert into Skill values(04,'Urology');
insert into Skill values(01,'Oncology');
insert into Skill values(06,'Neurology');
insert into Skill values(07,'Opthalmology');
insert into Skill values(07,'Orthopedic');
insert into Skill values(08,'Cardiology');
/*Patient*/
create procedure insertion_P
@Patient_name varchar(20),
@Patient_type varchar(20),
@Sex varchar(8),
@Blood_group varchar(8),
@DOB date,
@Age int,
@Admit_date date,
@Adress varchar(30)
as 
begin
insert into Patient(Patient_name_,Patient_type,Sex,Blood_group,DOB,Age,Admit_date,Adress)
values(@Patient_name,@Patient_type,@Sex,@Blood_group,@DOB,@Age,@Admit_date,@Adress);
end

exec Insertion_P 'Asma Amir','Neural','Female','B+','2002-12-14',21,'2023-05-10','Shahdara Lahore';
exec Insertion_P 'Usman Khalid','Psychological','Male','A+','2001-09-04',22,'2022-11-10','Lahore';
exec Insertion_P 'Talha Waqar','Under-consideration','Male','A-','2001-07-14',22,'2023-05-28','Queta';
exec Insertion_P 'Wassam Shah','Muscular','Male','AB+','2001-09-01',21,'2020-05-10','DHA Lahore';
exec Insertion_P 'Rida Abrar','Urinary','Female','B+','2002-12-16',21,'2023-03-18','Shahdara Lahore';
exec Insertion_P 'Shahan Butt','Skin','Male','B+','2001-01-04',21,'2023-01-10','Johar Town Lahore';
exec Insertion_P 'Rameen Khan','Diabetic','Female','O+','2002-10-14',21,'2010-05-10','Gari shahu Lahore';
exec Insertion_P 'Saad Salam','Obese','Male','B+','2001-04-20',21,'2019-05-22','Kareem Park Lahore';
exec Insertion_P 'M Umer','Dental','Male','B+','2001-10-20',21,'2019-06-30','Farooqabad SKP';
insert into Phone_Num values(01,924441);
insert into Phone_Num values(02,925324);
insert into Phone_Num values(03,929870);
insert into Phone_Num values(04,920809);
insert into Phone_Num values(05,926544);
insert into Phone_Num values(06,923141);
insert into Phone_Num values(07,927646);
insert into Phone_Num values(08,928870);
/*Bill*/
insert into Bill(Patient_ID,Patient_name,Amount) values(01,'Asma Amir',80000);
insert into Bill(Patient_ID,Patient_name,Amount) values(02,'Usman Khalid',12500);
insert into Bill(Patient_ID,Patient_name,Amount) values(03,'Talha Waqar',4000);
insert into Bill(Patient_ID,Patient_name,Amount) values(04,'Wassam Shah',8000);
insert into Bill(Patient_ID,Patient_name,Amount) values(05,'Rida Abrar',7000);
insert into Bill(Patient_ID,Patient_name,Amount) values(06,'Shahan Butt',5000);
insert into Bill(Patient_ID,Patient_name,Amount) values(07,'Rameen Khan',9000);
insert into Bill(Patient_ID,Patient_name,Amount) values(08,'Saad Salam',3000);
insert into Bill(Patient_ID,Patient_name,Amount) values(09,'M Umer',2500);
/*Prescription*/
insert into Prescription values(01,01,'2023-05-10',NULL);
insert into Prescription values(02,02,'2023-04-19',01);
insert into Prescription values(03,03,'2023-05-28',01);
insert into Prescription values(04,04,'2023-05-19',02);
insert into Prescription values(05,05,'2023-02-11',03);
insert into Prescription values(06,06,'2023-01-22',02);
insert into Prescription values(07,07,'2023-05-25',02);
insert into Prescription values(08,08,'2023-04-09',04);

/*Pharmacy*/
insert into Pharmacy values('Asma Amir',1500);
insert into Pharmacy values('Usman Khalid',00);
insert into Pharmacy values('Talha Waqar',500);
insert into Pharmacy values('Wassam Shah',1200);
insert into Pharmacy values('Rida Abrar',700);
insert into Pharmacy values('Shahan Butt',500);
insert into Pharmacy values('Rameen Khan',2000);
insert into Pharmacy values('Saad Salam',00);

/*Room*/
insert into Room values(07,'Emergrncy');
insert into Room values(05,'OPD');
insert into Room values(08,'Emergency');
insert into Room values(02,'Orthopedics');
insert into Room values(06,'Pediatrics');
insert into Room values(04,'OPD');
insert into Room values(01,'Surgical');
insert into Room values(03,'OPD');
/*Laboratory*/
insert into Laboratory values('Naeem Ahmad','Shujah Haider',987,'Male','naeem09@gmail.com','Radiology_Lab',15000,01);
insert into Laboratory values('Danish Ali','Arif Umer',640,'Male','danishali09@gmail.com','Emergency_Lab',17000,03);
insert into Laboratory values('Abu-Bakar','Adil Sohail',742,'Male','abu.bakar@gmail.com','Surgical_Lab',12000,07);
insert into Laboratory values('Bushra Bibi','Razia Sultan',540,'Female','Bushra00@gmail.com','Radiology _Lab',15000,05);
insert into Number values('Naeem Ahmad',923333);
insert into Number values('Danish Ali',923443);
insert into Number values('Abu-Bakar',923239);
insert into Number values('Bushra Bibi',923340);
/*Receptionist*/
create procedure insertdata_R
@R_Name varchar(15),
@User_Nam varchar(15),
@Paswrd int,
@Gender varchar(8),
@Email_ID varchar(50),
@Salary int,
@Patient_ID int
as 
begin
insert into Receptionist(R_Name,User_Nam,Paswrd,Gender,Email_ID,Salary,Patient_ID)
values(@R_Name,@User_Nam,@Paswrd,@Gender,@Email_ID,@Salary,@Patient_ID);
end
exec insertdata_R 'Zunaira Ali','Umer',456,'Female','zunaira02@gmail.com',20000,01;
exec insertdata_R 'Furqan Ahmad','Aqib',601,'Male','Furqanahmad@gmail.com',22000,02;
exec insertdata_R 'Muhammad Jameel','Sohail',994,'Male','Jameel07@gmail.com',17000,03;
exec insertdata_R 'Rubab Khurram','Ali',230,'Female','rubab__@gmail.com',20000,04;
exec insertdata_R 'Zuriat Naeem','Umer',654,'Female','zuriat02@gmail.com',20000,05;
exec insertdata_R 'Waqas Khan','Aqib Ali',106,'Male','waqaskhan@gmail.com',22000,06;
exec insertdata_R 'Aslam Ali','Sohail',954,'Male','Ali07@gmail.com',17000,07;
exec insertdata_R 'Furqan Ali','Aqib Ali',639,'Male','Furqan@gmail.com',22000,08;
insert into Contact values('Zunaira Ali',921001);
insert into Contact values('Furqan Ahmad',921111);
insert into Contact values('Muhammad Jameel',924512);
insert into Contact values('Rubab Khurram',921199);
/*Nurse*/
insert into Nurse values('Fakhar Jawad','Abid',579,70000,'Female','Lahore');
insert into Nurse values('Abdul Jabbar','Khurram',975,50000,'Male','Lahore');
insert into Nurse values('Abdul Rehman','Liaqat',452,55000,'Male','Karachi');
insert into Nurse values('Ayesha Rehmat','Jamal',339,72000,'Female','Lahore');
insert into Nurse values('Anoushe Bajwa','Shafqat',502,45000,'Female','Islamabad');
insert into Nurse values('Abdullah Ali','Ashraf',002,80000,'Male','Lahore');
insert into Nurse values('Babar Shokat','Rashid',931,34000,'Male','Quetta');
insert into Nurse values('Nazia Bano','Wseem',051,85000,'Female','Rawalpindi');
insert into Nurse values('Razia Sultan','Asghar',702,60000,'Female','Rawalpindi');
insert into Nurse values('Uzma Parveen','Iqbal',489,90000,'Female','Multan');
insert into Mobile values('Fakhar Jawad',9245798);
insert into Mobile values('Abdul Jabbar',92056689);
insert into Mobile values('Abdul Rehman',92198757);
insert into Mobile values('Ayesha Rehmat',92936785);
insert into Mobile values('Anoushe Bajwa',92456880);
insert into Mobile values('Abdullah Ali',92336720);
insert into Mobile values('Babar Shokat',92882460);
insert into Mobile values('Nazia Bano',92123789);
insert into Mobile values('Razia Sultan',92005783);
insert into Mobile values('Uzma Parveen',92023839);
/*Aedmin*/
CREATE PROCEDURE insert_A
@Admin_Name varchar(15),
@User_Nam varchar(15),
@Paswrd int,
@Gender varchar(8),
@Email_ID varchar(50),
@Salary int,
@T_Name varchar(15),
@Room_cheaking int,
@Worker_Name varchar(15),
@Bill int 
as 
begin
insert into Aedmin(Admin_Name,User_Nam,Paswrd,Gender,Email_ID,Salary,T_Name,Room_cheaking,Worker_Name,Bill)
values(@Admin_Name,@User_Nam,@Paswrd,@Gender,@Email_ID,@Salary,@T_Name,@Room_cheaking,@Worker_Name,@Bill);
end
exec insert_A 'Adeel Hayat','Nouman',356,'Male','ade.el@gmail.com',200000,'Naeem Ahmad',01,'Fakhar Jawad',01;
exec insert_A 'Nabeel Bukhari','Zubair',854,'Male','nabe.el@gmail.com',150000,'Danish Ali',05,'Abdul Jabbar',05;
exec insert_A 'Malik Ahsan','Hanif',444,'Male','Malik@gmail.com',3700000,'Abu-Bakar',04,'Ayesha Rehmat',07;
exec insert_A 'Asmat Kazmi','Zakriya',450,'Male','Kazmi@gmail.com',300000,'Bushra Bibi',06,'Razia Sultan',03;
insert into Phone values('Adeel Hayat',921481);
insert into Phone values('Nabeel Bukhari',921777);
insert into Phone values('Malik ahsan',9214912);
insert into Phone values('Asmat Kazmi',921759);

/*Patient_Cheakup*/
insert into Patient_Cheakup(N_Name) values('Fakhar Jawad');
insert into Patient_Cheakup(N_Name) values('Abdul Jabbar');
insert into Patient_Cheakup(N_Name) values('Abdul Rehman');
insert into Patient_Cheakup(N_Name) values('Ayesha Rehmat');
insert into Patient_Cheakup(N_Name) values('Anoushe Bajwa');
insert into Patient_Cheakup(N_Name) values('Abdullah Ali');
insert into Patient_Cheakup(N_Name) values('Nazia Bano');
insert into Patient_Cheakup(N_Name) values('Razia Sultan');
insert into Patient_Cheakup(N_Name) values('Uzma Parveen');

/*Diagnosis*/
insert into Diagnosis values (1,1);
insert into Diagnosis values (2,2);
insert into Diagnosis values (3,3);
insert into Diagnosis values (4,4);
insert into Diagnosis values (5,5);
insert into Diagnosis values (6,6);
insert into Diagnosis values (7,7);
insert into Diagnosis values (8,8);

/*Medical Shop*/
insert into Medical_Shop(Med_Bill_no) values (1);
insert into Medical_Shop(Med_Bill_no) values (2);
insert into Medical_Shop(Med_Bill_no) values (3);
insert into Medical_Shop(Med_Bill_no) values (4);
insert into Medical_Shop(Med_Bill_no) values (5);
insert into Medical_Shop(Med_Bill_no) values (6);
insert into Medical_Shop(Med_Bill_no) values (7);
insert into Medical_Shop(Med_Bill_no) values (8);

/*----------------------------------------------------------------------------------------------------------------------------------------------*/

/*-----------------------------------------------------Project 3rd Phase-----------------------------------------------------------------------*/
/*------------------------------------------------LOGICAL OPERATORS--------------------------------------------------------------------------*/

/*--------------------( 1 )--------------*/


--Display all doctors whose salary is between 5000 and 7000
select * from Doctor where Salary between 1200000 and 1700000;


/*--------------------( 2 )--------------*/


--Display all patients who have blood group 'AB+' or 'O-'
select * from Patient where Blood_group in ('AB+', 'O-');


/*--------------------( 3 )--------------*/


--Display all doctors who are not male.
select * from Doctor where Sex = 'Male' and Cabin_no > 5;


/*--------------------( 4 )--------------*/


--Display the address of Patient where condition is not critical
select * from Patient where Patient_type <> 'Emergency';



/*--------------------( 5 )--------------*/


--Display all doctors whose First name starts with 'J' or 'R'.
select * from Doctor where First_name like 'Dr.J%' OR First_name LIKE 'Dr.R%';



/*--------------------( 6 )--------------*/


--Display all patients whose address does not contains the word 'Street'.
select * from Patient where Adress not like '%Street%';


/*--------------------( 7 )--------------*/


--Display all doctors whose email addresses end with '@gmail.com'.
select * from Doctor where Email_ID like '%@gmail.com';




/*--------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------JOINS--------------------------------------------------------------------------*/

/*--------------------( 1 )--------------*/


--Display the details of patients along with their assigned doctors.
select Patient.Patient_ID, Patient.Patient_name_, Doctor.First_name as Doctor_Assigned
from Patient
join Diagnosis on Patient.Patient_ID = Diagnosis.Patient_ID
join Doctor on Doctor.Doc_ID = Diagnosis.Patient_ID


/*--------------------( 2 )--------------*/


--Display the bill details along with the corresponding patient's name.
select Bill.Bill_no, Bill.Amount, Patient.Patient_name_
from Bill
inner join Patient on Bill.Patient_ID = Patient.Patient_ID;


/*--------------------( 3 )--------------*/


--Display the prescription details along with the corresponding patient's name and doctor's name.
select Prescription.Presc_ID, Prescription.Date_, 
Patient.Patient_name_, Doctor.First_name as Doctor_Assigned
from Prescription
inner join Patient on Prescription.Patient_ID = Patient.Patient_ID
inner join Doctor on Prescription.Doc_ID = Doctor.Doc_ID;


/*--------------------( 4 )--------------*/


--Display the patients along with their assigned rooms and their location.
select Patient.Patient_ID, Patient.Patient_name_, Room.Room_no, Room.Locat
from Patient
inner join Room on Patient.Patient_ID = Room.Room_no;


/*--------------------( 5 )--------------*/


--Display the details of patients along with their bill details, the corresponding doctor's name.
select Patient.Patient_ID, Patient.Patient_name_, Bill.Bill_no, Bill.Amount,
Doctor.First_name as Doctor_Assigned
from Patient
left join Bill on Patient.Patient_ID = Bill.Patient_ID
left join Diagnosis on Patient.Patient_ID = Diagnosis.Patient_ID
left join Doctor on Doctor.Doc_ID = Diagnosis.Doc_ID
left join Medical_Shop on Patient.Patient_ID = Medical_Shop.Patient_ID
left join Pharmacy on Pharmacy.Med_Bill_no = Medical_Shop.Med_Bill_no

drop database Hospital;
/*--------------------( 6 )--------------*/


--Display the details of patients along with their assigned rooms and the receptionist details who admitted them.
select Patient.Patient_ID, Patient.Patient_name_, 
Room.Room_no, Room.Locat, Receptionist.R_Name
from Patient
inner join Room on Patient.Patient_ID = Room.Room_no
left join Receptionist on Patient.Patient_ID = Receptionist.Patient_ID;


/*--------------------( 7 )--------------*/


--Retrieve the patients along with the corresponding nurse details who is taking care of them.
select Patient.Patient_ID, Patient.Patient_name_, Nurse.N_Name
from Patient
left join Patient_Cheakup on Patient.Patient_ID = Patient_Cheakup.Patient_ID
left join Nurse on Nurse.N_Name = Patient_Cheakup.N_Name;


/*---------------------------------------------------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------AGGREGATE FUNCTIONS-----------------------------------------------------------------*/

/*--------------------( 1 )--------------*/


--Display the distinct blood groups of all patients.
select distinct Blood_group from Patient;


/*--------------------( 2 )--------------*/


--Display the count of patients for each blood group.
select Blood_group, count(*) as Total_Patients from Patient
group by Blood_group;


/*--------------------( 3 )--------------*/


--Display the average salary of doctors who have a salary greater than 5000.
select avg(Salary) as Average_Salary from Doctor
where Salary > 5000;


/*--------------------( 4 )--------------*/


--Retrieve the top 5 highest-paid doctors.
/* MySQL syntax --->     SELECT * FROM Doctor ORDER BY Salary DESC LIMIT 5;*/
select top 5 * from Doctor order by Salary desc;


/*--------------------( 5 )--------------*/


--Retrieve the total amount of bills for each patient, and display only those patients whose total bill amount is greater than 1000.
select Patient_ID, sum(Amount) as Total_Bill_Amount from Bill
group by Patient_ID, Amount
having Amount > 1000;


/*--------------------( 6 )--------------*/


--Select the average, maximum, and minimum values of the "Salary" from Doctors.
select AVG(Salary) as AverageSalary, max(Salary) as MaxSalary, min(Salary) as MinSalary
from Doctor;



/*--------------------( 7 )--------------*/


--Retrieve the patients along with their average age, grouped by their blood group, and sorted by the average age in ascending order.
select Blood_group, avg(Age) as Average_Age from Patient
group by Blood_group order by Average_Age asc;


/*----------------------------------------------------------------------------------------------------------------------------------------------*/

/*---------------------------------------------------NESTED QURIES------------------------------------------------------------------*/

/*--------------------( 1 )--------------*/


--Select the patients who have a bill amount greater than the average bill amount of all patients.
select Patient_ID, Patient_name_ from Patient where Patient_ID in
    (select Patient_ID from Bill where Amount > 
       (select avg(Amount) from Bill));


/*--------------------( 2 )--------------*/


--Select the doctors who have treated patients with a blood group that is present in the Patient table.
select First_name as Doctor_First_Name, Last_Name as Doctor_Last_Name from Doctor where Doc_ID IN 
    (select Patient_ID from Patient where Blood_group in 
        (select distinct Blood_group from Patient));


/*--------------------( 3 )--------------*/


--Select the patients who have been admitted before any doctor with the last name "Rizwan."
select Patient_ID, Patient_name_ from Patient where Admit_date < 
    (select min(Admit_date) from Patient where Patient_ID in 
        (select Doc_ID from Doctor where Last_name = 'Rizwan'));


/*--------------------( 4 )--------------*/


/*Select the patients who have a bill amount greater than the average bill amount of patients
treated by doctors with a salary greater than the average salary of all doctors.*/
select Patient_ID, Patient_name_ from Patient where Patient_ID in 
    (select Patient_ID from Bill where Amount > 
        (select avg(Amount) from Bill where Patient_ID in 
            (select Doc_ID from Doctor where Salary > 
                (select avg(Salary) from Doctor))));


/*-----------------------------------------------------------------------------------------------------------------------------------------------*/

/*--------------------------------------------PROCEDURES + TRIGGERS + Views----------------------------------------------------------*/

/*--------------------( 1 )--------------*/


--Create a view that displays the details of doctors who have a salary greater than 130,0000.
create view High_Salary_Doctors 
as
select * from Doctor where Salary > 1300000;

select * from High_Salary_Doctors;


/*--------------------( 2 )--------------*/


--Create a stored procedure that displays the details of patients based on the given blood group.
create procedure Get_Patient
@Blood_group varchar(8)
as
begin
    select * from Patient where Blood_group = @Blood_group;
end;

execute Get_Patient 'AB+'


/*--------------------( 3 )--------------*/


--Create a view that displays the details of female doctors from the "Doctor" table.
create view Female_Doctors 
as
select * from Doctor where Sex = 'Female';

select * from Female_Doctors 


/*--------------------( 4 )--------------*/


--Create a stored procedure that displays the details of patients based on their type.
create procedure Patient_Details
@Patient_type varchar(20)
as
begin
    select * from Patient where Patient_type = @Patient_type;
end;

exec Patient_Details 'Psychological'


/*--------------------( 5 )--------------*/


--Create trigger that display the table whenever any change occurs to it.
create trigger Display_Parm on Pharmacy
after insert,update,delete
as begin 
select * from Pharmacy
end

/*--------------------------------------------------------------------------------------------------------------------------------------------*/




/*-------------------------------------------------Triggers-----------------------------------------------*/
/*Doctor*/
create trigger Display_Doc on Doctor
after insert,update,delete
as begin 
select * from Doctor
end

create trigger Display_No on Phone_No
after insert,update,delete
as begin 
select * from Phone_No
end

create trigger Display_Skill on Skill
after insert,update,delete
as begin 
select * from Skill
end
/*Patient*/
create trigger Display_Pat on Patient
after insert,update,delete
as begin 
select * from Patient
end

create trigger Display_Num on Phone_Num
after insert,update,delete
as begin 
select * from Phone_Num
end
/*Bill*/
create trigger Display_Bill on Bill
after insert,update,delete
as begin 
select * from Bill
end
/*Prescription*/
create trigger Display_Presc on Prescription
after insert,update,delete
as begin 
select * from Prescription
end
/*Pharmacy*/
create trigger Display_Parm on Pharmacy
after insert,update,delete
as begin 
select * from Pharmacy
end
/*Room*/
create trigger Display_Room on Room
after insert,update,delete
as begin 
select * from Room
end
/*Laboratory*/
create trigger Display_Lab on Laboratory
after insert,update,delete
as begin 
select * from Laboratory
end

create trigger Display_Number on Number
after insert,update,delete
as begin 
select * from Number
end
/*Receptionist*/
create trigger Display_Reception on Receptionist
after insert,update,delete
as begin 
select * from Receptionist
end

create trigger Display_Contact on Contact
after insert,update,delete
as begin 
select * from Contact
end
/*Nurse*/
create trigger Delete_Nurses on Nurse
after delete,update,insert
as begin
select * from Nurse
end

create trigger Display_Mobile on Mobile
after insert,update,delete
as begin 
select * from Mobile
end
/*Aedmin*/
create trigger Display_Admin on Aedmin
after insert,update,delete
as begin 
select * from Aedmin
end

create trigger Display_Phone on Phone
after insert,update,delete
as begin 
select * from Phone
end

/*----------------------------------------Search Procedures in each Table---------------------------------------------*/
/*Doctor*/
create procedure Search_Doctor
@Doc_ID int
as
begin
select * from Doctor
where Doc_ID = @Doc_ID;
end

create procedure Search_No
@Doc_ID int
as
begin
select * from Phone_No
where Doc_ID = @Doc_ID;
end

create procedure Search_Skill
@Doc_ID int
as
begin
select * from Skill
where Doc_ID = @Doc_ID;
end
/*Patient*/
create procedure Search_Patient
@Patient_ID int
as
begin
select * from Patient
where Patient_ID = @Patient_ID;
end

create procedure Search_Num
@Patient_ID int
as
begin
select * from Phone_Num
where Patient_ID = @Patient_ID;
end
/*Bill*/
create procedure Search_Bill
@Patient_name varchar(20)
as
begin
select * from Bill
where Patient_name = @Patient_name;
end
/*Prescription*/
create procedure Search_Presc
@Presc_ID int
as
begin
select * from Prescription
where Presc_ID = @Presc_ID;
end
/*Pharmacy*/
create procedure Search_Pharm
@Patient_name_ varchar(20)
as
begin
select * from Pharmacy
where Patient_name_ = @Patient_name_;
end
/*Room*/
create procedure Search_Room
@Room_no int
as
begin
select * from Room
where Room_no = @Room_no;
end
/*Receptionist*/
create procedure Search_Receptionist
@R_Name varchar(20)
as
begin
select * from Receptionist
where R_Name = @R_Name;
end

create procedure Search_Contact
@R_Name varchar(20)
as
begin
select * from Contact
where R_Name = @R_Name;
end
/*Laboratory*/
create procedure Search_Lab
@T_name varchar(20)
as
begin
select * from Laboratory
where T_name = @T_name;
end

create procedure Search_Number
@T_name varchar(20)
as
begin
select * from Number
where T_name = @T_name;
end
/*Nurse*/
create procedure Search_Nurse
@N_Name varchar(20)
as
begin
select * from Nurse
where N_Name = @N_Name;
end

create procedure Search_Mobile
@N_Name varchar(20)
as
begin
select * from Mobile
where N_Name = @N_Name;
end
/*Aedmin*/
create procedure Search_Admin
@Admin_Name varchar(20)
as
begin
select * from Aedmin
where Admin_Name = @Admin_Name;
end

create procedure Search_Phone
@Admin_Name varchar(20)
as
begin
select * from Phone
where Admin_Name = @Admin_Name;
end

/*Execution*/

exec Search_Doctor 02;
exec Search_No 02;
exec Search_Skill 02;
exec Search_Patient 02;
exec Search_Num 02;
exec Search_Bill 'Shahan Butt';
exec Search_Presc 02;
exec Search_Pharm 'Asma Amir';
exec Search_Room 05;
exec Search_Receptionist 'Zuriat Naeem';
exec Search_Contact 'Rubab Khuram';
exec Search_Lab 'Abu-Bakar';
exec Search_Number 'Naeem Ahmad';
exec Search_Nurse 'Anoushe Bajwa';
exec Search_Mobile 'Abdul Jabbar' ;
exec Search_Admin 'Nabeel Bukhari';
exec Search_Phone 'Asmat Kazmi';

/*-------------------------------------------------------------END----------------------------------------------------------------------*/