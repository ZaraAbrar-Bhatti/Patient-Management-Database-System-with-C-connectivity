create  database Hospital;
use Hospital;

/*----------------------------Creating Tables of entities-------------------------*/
create table Doctor(
Doc_ID int identity(1,1) primary key,
First_name varchar(20),
Last_name varchar(20),
Paswrd varchar(10),
Sex varchar(8),
Salary float,
Email_ID varchar(50),
Cabin_no int
)
create table Phone_No(                                        /*Multivalued attribute*/
Doc_ID int foreign key references Doctor(Doc_ID),
Phone_no int,
)
create table Skill(                                          /*Multivalued attribute*/
Doc_ID int foreign key references Doctor(Doc_ID),
Specialization varchar(20),
)

create table Patient(
Patient_ID int identity(1,1) primary key,
Patient_name_ varchar(20),
Patient_type varchar(20),
Sex varchar(8),
Blood_group varchar(8),
DOB date,
Age int,
Admit_date date,
Adress varchar(30),
)
create table Phone_Num(                                     /*Multivalued attribute*/
Patient_ID int foreign key references Patient(Patient_ID),
Phone_no int,
)

create table Bill(                                         /*Weak Entity*/
Bill_no int identity(1,1),
Patient_ID int,
Patient_name varchar(20),
Amount int,
primary key(Bill_no,Patient_ID),
foreign key(Patient_Id) references Patient(Patient_ID)     /*Weak Relation b/w Patient-Bill*/
)

create table Prescription(
Presc_ID int identity(1,1) primary key,                                              /*Weak Entity*/
Patient_ID int,
Doc_ID int,
Date_ date,
foreign key (Patient_ID) references Patient(Patient_ID),               /*Weak Relation b/w Patient-Prescription*/
Presc_hierarchy int foreign key references Prescription(Presc_ID),     /*Recurssive Relation*/
)

create table Pharmacy(
Med_Bill_no int identity(1,1) primary key,
Patient_name_ varchar(20),
Amount float
)

create table Room(                                               /*Relation b/w Patient-Room*/
Room_no int primary key,
Locat varchar(40),
foreign key (Room_no) references Patient(Patient_ID)
)

create table Laboratory(
T_name varchar(15) primary key,
User_nam varchar(15),
Paswrd int,
Gender varchar(8),
Email_ID varchar(50),
Adress varchar(30),
Salary int,
Patient_ID int foreign key references Patient(Patient_ID),            /*Relation b/w Patient-Lab*/
)
create table Number(                                                  /*Multivalued attribute*/
T_Name varchar(15) foreign key references Laboratory(T_Name),
Phone_no int,
)

create table Receptionist(
R_Name varchar(15) primary key,
User_Nam varchar(15),
Paswrd int,
Gender varchar(8),
Email_ID varchar(50),
Salary int,
Patient_ID int foreign key references Patient(Patient_ID)                         /*Relation b/w Patient-Receptionist*/
)
create table Contact(                                                            /*Multivalued attribute*/
R_Name varchar(15) foreign key references Receptionist(R_Name),
Phone_no int,
)

create table Nurse(
N_Name varchar(15) primary key,
User_Nam varchar(15),
Paswrd int,
Salary int,
Gender varchar(8),
Adress varchar(30),         
)
create table Mobile(                                      /*Multivalued attribute*/
N_Name varchar(15) foreign key references Nurse(N_Name),
Phone_no int,
)

create table Aedmin(
Admin_Name varchar(15) primary key,
User_Nam varchar(15),
Paswrd int,
Gender varchar(8),
Email_ID varchar(50),
Salary int,
T_Name varchar(15) foreign key references Laboratory(T_Name),           /*Relation b/w Lab-Aedmin*/
Room_cheaking int foreign key references Room(Room_no),                  /*Relation b/w Room-Aedmin*/
Worker_Name varchar(15) foreign key references Nurse(N_Name),              /*Relation b/w Nurse-Aedmin*/
Bill int foreign key references Pharmacy(Med_Bill_no),                     /*Relation b/w Pharmacy-Aedmin*/
)
create table Phone(                                                     /*Multivalued attribute*/
Admin_Name varchar(15) foreign key references Aedmin(Admin_Name),
Phone_no int,
)

/*-------------------------Creating Tables for relations----------------------*/
create table Diagnosis(                                 /*Relation b/w Patient-Doctor*/
Doc_ID int foreign key references Doctor(Doc_ID),
Patient_ID int foreign key references Patient(Patient_ID)
)

create table Medical_Shop(                              /*Relation b/w Patient-Pharmacy*/
Shop_No int,
Locat varchar(30),
Patient_ID int foreign key references Patient(Patient_ID),
Med_Bill_no int foreign key references Pharmacy(Med_Bill_no),
)

create table Patient_Cheakup(                          /*Relation b/w Patient-Nurse*/     
N_Name varchar(15) foreign key references Nurse(N_Name),
Patient_ID int foreign key references Patient(Patient_ID)
)

/*---------------------------------------------------------------------------------------------------------------------------------------------*/